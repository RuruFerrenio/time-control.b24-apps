<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <script src="//api.bitrix24.com/api/v1/"></script>
    <title>Установка</title>
</head>
<body>
Ошибка при установке приложения. Повторите попытку позже, либо обратитесь в тех поддержку
</body>
</html>
