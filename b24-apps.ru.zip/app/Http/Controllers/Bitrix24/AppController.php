<?php

namespace App\Http\Controllers\Bitrix24;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\View\View;
use X3Group\Bitrix24\Bitrix24ApiClient;

class AppController extends Controller
{
    public function index(Bitrix24ApiClient $bitrix24, Request $request): View
    {
        return view('b24api.index');
    }
}
